﻿namespace ECommerce.Application;

public static class AssemblyReference
{
}