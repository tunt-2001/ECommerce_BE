﻿namespace ECommerce.Application.Features.Categories.Queries.GetAllCategories;

public class CategoryDto
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
}